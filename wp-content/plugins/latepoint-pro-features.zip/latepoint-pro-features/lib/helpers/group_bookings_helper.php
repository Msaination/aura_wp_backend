<?php 

class OsGroupBookingsHelper {

}
